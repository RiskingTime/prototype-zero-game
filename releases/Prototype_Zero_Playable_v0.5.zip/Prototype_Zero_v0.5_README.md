# Prototype Zero v0.5

This build focuses on the latest playtest feedback:

- Movement now prefers a direct, human-readable diagonal/straight path and only detours when necessary.
- Combat log runs chronologically from top to bottom and auto-scrolls to the newest entry.
- Invalid move/attack attempts are logged and their explanation remains in the status panel until the next interaction.
- Initiative is collapsed to a one-line strip by default and expands on click.
- Standalone Attack Info button removed; attack information lives in the character panel/sheet and target hover.
- Character sheet now shows all five prototype attributes plus equipment and attack details.
- Back to Battlefield button is explicitly wired to restore the grid while preserving combat state.

Run `Prototype_Zero_v0.5.html` in a modern browser.
